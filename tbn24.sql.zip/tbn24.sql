-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2020 at 12:14 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tbn24`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_phone` varchar(13) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registered_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `email`, `user_phone`, `password`, `status`, `picture`, `registered_date`) VALUES
(13, 'ddd', 'a@gmail.com', '5555555555555', 'c4ca4238a0b923820dcc509a6f75849badmin', 'super-admin', '1600763415.webp', '2020-09-22'),
(14, 'isolutions', 'admin@isolutionsbd.com', '0173830567', '7ece99e593ff5dd200e2b9233d9ba654admin', 'super-admin', '1601210874.webp', '2020-09-27');

-- --------------------------------------------------------

--
-- Table structure for table `app_seating`
--

CREATE TABLE `app_seating` (
  `app_setting_id` int(11) NOT NULL,
  `app_time_zone` varchar(100) DEFAULT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `google_app_id` varchar(100) DEFAULT NULL,
  `instagram_id` varchar(100) DEFAULT NULL,
  `live_url` varchar(250) DEFAULT NULL,
  `live_url_bd` varchar(250) DEFAULT NULL,
  `program_start_type` varchar(50) DEFAULT NULL,
  `youtube_chanel` varchar(250) DEFAULT NULL,
  `google_map` varchar(500) DEFAULT NULL,
  `contact_address` varchar(200) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `contact_email` varchar(20) DEFAULT NULL,
  `linkedIn` varchar(200) DEFAULT NULL,
  `twitter` varchar(200) DEFAULT NULL,
  `ios_app_link` varchar(250) DEFAULT NULL,
  `after_login_alert` int(11) DEFAULT NULL,
  `before_login_alert` int(11) DEFAULT NULL,
  `five_minite_modal_note` varchar(250) DEFAULT NULL,
  `one_hour_modal_note` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `app_seating`
--

INSERT INTO `app_seating` (`app_setting_id`, `app_time_zone`, `facebook`, `google_app_id`, `instagram_id`, `live_url`, `live_url_bd`, `program_start_type`, `youtube_chanel`, `google_map`, `contact_address`, `contact_phone`, `contact_email`, `linkedIn`, `twitter`, `ios_app_link`, `after_login_alert`, `before_login_alert`, `five_minite_modal_note`, `one_hour_modal_note`) VALUES
(1, 'America/New_York', 'https://www.facebook.com/tbn24usa', 'https://play.google.com/store/apps/details?id=com.tbn.live', 'https://www.instagram.com/tbn24usa/', 'http://dog.dg21bd.com/TBN242/index.m3u8', 'http://dog.dg21bd.com/TBN242/index.m3u8', 'manualy', 'UCv_oQ-sRZoJdEX4K5fQ6q6w', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.5574698989853!2d-73.90740168483684!3d40.749762043241915!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25f1bece75213%3A0x43f4dd9a13836756!2s37-19+57th+St%2C+Flushing%2C+NY+11377%2C+USA!5e0!3m2!1sen!2sbd!4v1495992827453', '37-19, 57th street, woodside,NY-11377 United States', '+1(718)808-9000', 'infotban24@gggg.', NULL, NULL, 'https://play.google.com/store/apps/details?id=com.tbn.live', 60, 60, 'Commign soon', 'Commign soon');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_title` varchar(200) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_title`, `status`, `created_date`) VALUES
(2, 'Mango', 1, '2020-09-28'),
(3, 'computer', 1, '2020-09-28'),
(4, 'Cpu', 1, '2020-10-06');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `contact_id` int(11) NOT NULL,
  `contact_name` varchar(50) NOT NULL,
  `contact_email` varchar(50) NOT NULL,
  `contact_subject` varchar(250) NOT NULL,
  `contact_message` text NOT NULL,
  `status` tinyint(4) DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`contact_id`, `contact_name`, `contact_email`, `contact_subject`, `contact_message`, `status`, `created_date`) VALUES
(1, 'sujon', 'admin@isolutionsbd.com', 'dd', 'ff', 1, '2020-09-27 00:00:00'),
(2, 'sujon', 'info@isolutionsbd.com', 'fff', 'd', 1, '2020-09-27 00:00:00'),
(3, 'sujon', 'admin@isolutionsbd.com', 'dd', 'dd', 1, '2020-09-27 00:00:00'),
(4, 'shahinul islam', 'suzonice10@gmal.com', 'how  can help you ?', 'I need your help  I need your help I need your help \r\nI need your help  I need your help I need your help \r\nI need your help  I need your help I need your help', 1, '2020-09-27 18:41:12'),
(5, 'I need your help I need', 'email@gmail.com', 'I need your help I need', 'I need your help I need your help I need your help I need your help I need your help I need your help I need your help I need your help I need your help', 1, '2020-10-04 16:51:25');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `faq_id` int(11) NOT NULL,
  `questions` varchar(250) DEFAULT NULL,
  `answers` varchar(250) DEFAULT NULL,
  `created_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`faq_id`, `questions`, `answers`, `created_date`) VALUES
(4, 'd', 'dd', '2020-09-30');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_09_22_073017_create_programs_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `news_id` int(11) NOT NULL,
  `news_title` varchar(250) DEFAULT NULL,
  `news_body` varchar(500) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `create_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_id`, `news_title`, `news_body`, `status`, `create_date`) VALUES
(1, 'dayly news id', 'bangla today', 1, '0000-00-00'),
(2, 'dorkar nai', 'vat kai si', 1, '2020-09-28');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `option_id` int(11) NOT NULL,
  `option_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`option_id`, `option_name`, `option_value`) VALUES
(59, 'home_page_category_id', '58,65'),
(60, 'logo', 'https://demo.bestearnidea.com/wp-content/uploads/file/logo-gif.gif'),
(61, 'icon', 'https://sohojbuy.com/public/uploads/logo f.png'),
(62, 'site_title', 'Solehin Online Shopping'),
(63, 'order_image', NULL),
(64, 'phone', '01300884747'),
(65, 'phone_order', '<i class=\"fa fa-phone-square\" style=\"padding-left:20px;color: green;\">   </i> 01300884747 <br>\r\n <i class=\"fa fa-phone-square\" style=\"padding-left:20px;color: green;\"> </i> 01407011239 <br>'),
(66, 'address', '<ul class=\"toggle-footer\" style=\"\">\r\n                            <li class=\"media\">\r\n                                <div class=\"pull-left\">\r\n                      <span class=\"icon fa-stack fa-lg\">\r\n                      <i class=\"fa fa-map-marker fa-stack-1x fa-inverse\"></i>\r\n                      </span>\r\n                                </div>\r\n                                <div class=\"media-body\">\r\n                                    <p>Office no 1417, Level 13, Shah Ali Plaza, Mirpur 10, Dhaka</p>\r\n                                </div>\r\n                            </li>\r\n                            <li class=\"media\">\r\n                                <div class=\"pull-left\">\r\n                      <span class=\"icon fa-stack fa-lg\">\r\n                      <i class=\"fa fa-mobile fa-stack-1x fa-inverse\"></i>\r\n                      </span>\r\n                                </div>\r\n                                <div class=\"media-body\">\r\n                                    <p>01300884747<br>01300884747</p>\r\n                                </div>\r\n                            </li>\r\n                            <li class=\"media\">\r\n                                <div class=\"pull-left\">\r\n                      <span class=\"icon fa-stack fa-lg\">\r\n                      <i class=\"fa fa-envelope fa-stack-1x fa-inverse\"></i>\r\n                      </span>\r\n                                </div>\r\n                                <div class=\"media-body\">\r\n                                    <span><a href=\"#\">support@sohojbuy.com</a></span>\r\n                                </div>\r\n                            </li>\r\n                        </ul>'),
(67, 'admin_email', 'info@sohojbuy.com'),
(68, 'shipping_charge_in_dhaka', '60'),
(69, 'shipping_charge_out_of_dhaka', '120'),
(70, 'footer', NULL),
(71, 'google_map', NULL),
(72, 'copyright', NULL),
(73, 'default_product_terms', NULL),
(74, 'home_cat_section', '1,18,2,102,4,9,16,113,124'),
(75, 'home_seo_title', 'hhh'),
(76, 'home_seo_content', NULL),
(77, 'home_seo_keywords', NULL),
(78, 'home_about_title', NULL),
(79, 'home_about_content', NULL),
(80, 'bkash', '01748188268'),
(81, 'facebook', 'https://www.facebook.com/sohojbuyshop'),
(82, 'youtube', 'https://www.youtube.com/channel/UCWA3XLqrBLNItdEXNAcZVSA'),
(83, 'twitter', NULL),
(84, 'linked', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `page_id` int(11) NOT NULL,
  `page_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`page_id`, `page_name`, `page_link`, `page_content`, `created_time`) VALUES
(14, 'About Us', 'about-us', '<h1 style=\"text-align:center\"><strong>The voice of Non Resident Bangladeshis</strong></h1>\r\n\r\n<h4 style=\"text-align:center\">TBN24 is a Bangla language live television channel in North America provides content that is informative, educational, socially responsible, entertaining and comparable with world-class television broadcasters. TBN24 is the first Bangla 24x7 live television channel to produce original content here in the USA. This channel is currently available in US, Canada, Europe, Australia, and Middle-East.</h4>\r\n\r\n<p>TBN24 Television is the for non-resident Bangladeshi living across the globe as well as people whose mother tongue is Bangla</p>\r\n\r\n<p>This is a test to see download shows up here</p>', '2020-09-23 11:23:40'),
(15, 'documents', 'documents', '<h2>Covid-19 Eviction Moratorium</h2>\r\n\r\n<p><br />\r\nরোগ নিয়ন্ত্রণ ও প্রতিরোধ কেন্দ্র (সিডিসি) একটি অস্থায়ী উচ্ছেদের স্থগিতাদেশ ঘোষণা করেছে ডিসেম্বর 2020 পর্যন্ত । এই নির্বাহী আদেশ, বছরে $99,000 এর চেয়ে কম উপার্জনকারী ব্যক্তি এবং বিবাহিত দম্পতিদের $198,000 ডলারের কম আয়ের ক্ষেত্রে প্রযোজ্য, যারা COVID মহামারীর কারণে ভাড়া বা আবাসন প্রদান করতে অক্ষম হন।<br />\r\nযদি এই পরিস্থিতি আপনার ক্ষেত্রে প্রযোজ্য হয় তাহলে, আমরা একটি চিঠি তৈরি করেছি যা আপনি পূরণ করে, আপনার বাড়িওয়ালাকে সরবরাহ করতে পারেন।<br />\r\nআমাদের পিডিএফ ডাউনলোড করতে নীচের লিঙ্ক এ ক্লিক করুন।</p>', '2020-09-24 11:55:16');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `playlists`
--

CREATE TABLE `playlists` (
  `playlist_id` int(11) NOT NULL,
  `playlist_name` varchar(100) NOT NULL,
  `playlist_link` varchar(250) NOT NULL,
  `playlist_picture` varchar(100) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `created_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `playlists`
--

INSERT INTO `playlists` (`playlist_id`, `playlist_name`, `playlist_link`, `playlist_picture`, `category_id`, `created_date`) VALUES
(3, 'ddd', 'fff', '1601292605.webp', 2, '2020-09-28'),
(4, 'ddd', 'fff', 'playlist_1601293723.webp', 3, '2020-09-28');

-- --------------------------------------------------------

--
-- Table structure for table `popular_video`
--

CREATE TABLE `popular_video` (
  `id` int(11) NOT NULL,
  `video_name` varchar(525) NOT NULL,
  `video_id` varchar(250) NOT NULL,
  `order_by` int(11) DEFAULT NULL,
  `created_data` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `popular_video`
--

INSERT INTO `popular_video` (`id`, `video_name`, `video_id`, `order_by`, `created_data`) VALUES
(1, 'How to Edit YouTube Video Like Pro With Filmora 9 | Bangla Tutorial For Beginner Part One', 'v_aKYfgqbo84', 2, '2020-10-15'),
(2, 'Wondershare Filmora Full Bangla Tutorial for Beginners | All in One!', 'LI2vA0O9d3g', 57, '2020-10-16');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL,
  `post_title` varchar(250) NOT NULL,
  `post_name` varchar(200) NOT NULL,
  `post_picture` varchar(200) NOT NULL,
  `post_description` text NOT NULL,
  `post_created_date` date NOT NULL DEFAULT current_timestamp(),
  `post_status` tinyint(4) NOT NULL DEFAULT 0,
  `post_man` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `post_title`, `post_name`, `post_picture`, `post_description`, `post_created_date`, `post_status`, `post_man`) VALUES
(2, 'HSC, equivalent examinations cancelled, evaluation to be based on JSC, SSC results', 'hsc-equivalent-examinations-cancelled-evaluation-to-be-based-on-jsc-ssc-results', '1602061393.jpg', '<p>how are your</p>', '2020-10-07', 1, ''),
(3, 'Keepsakes are all she has', 'keepsakes-are-all-she-has', '1602061557.jpg', '<p>The books he used to read, the prizes he won, and the clothes he wore -- all are now stowed gracefully in a showcase, just the way Abrar Fahad used to keep them in his dormitory in Buet.</p>\r\n\r\n<p>A pair of blue sneakers that still looks new sits on the middle row. Just a row above lies his other belongings, starting from his wristwatch, spectacles, pen, prayer cap, tasbih, calculator, nail clipper to body lotion, toothbrush and hair oil.</p>\r\n\r\n<p>Identity cards of the university and his college rest in another row along with a yellow envelope which reads &quot;Welcome to EEE Family, Buet&quot;.</p>\r\n\r\n<p>His mother, Rokeya Begum, kept all these items as keepsakes in their house in Kushtia. Abrar died an agonising death after being beaten up brutally by some Chhatra League men at Buet&#39;s Sher-e-Bangla hall in the early hours of October 7 last year.</p>\r\n\r\n<p>Rokeya looks at these memories and speaks to herself in delirium.</p>', '2020-10-07', 1, ''),
(4, 'TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত', 'tbn-analysis--ep-822', '1602064023.jpg', '<p><a href=\"http://www.youtube.com/watch?v=K1SwqwHfViQ\" target=\"_blank\">TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত</a></p>', '2020-10-07', 1, ''),
(6, 'HSC, equivalent examinations cancelled, evaluation to be based on JSC, SSC results', 'hsc-equivalent-examinations-cancelled-evaluation-to-be-based-on-jsc-ssc-results', '1602061393.jpg', '<p>how are your</p>', '2020-10-07', 1, ''),
(7, 'Keepsakes are all she has', 'keepsakes-are-all-she-has', '1602061557.jpg', '<p>The books he used to read, the prizes he won, and the clothes he wore -- all are now stowed gracefully in a showcase, just the way Abrar Fahad used to keep them in his dormitory in Buet.</p>\r\n\r\n<p>A pair of blue sneakers that still looks new sits on the middle row. Just a row above lies his other belongings, starting from his wristwatch, spectacles, pen, prayer cap, tasbih, calculator, nail clipper to body lotion, toothbrush and hair oil.</p>\r\n\r\n<p>Identity cards of the university and his college rest in another row along with a yellow envelope which reads &quot;Welcome to EEE Family, Buet&quot;.</p>\r\n\r\n<p>His mother, Rokeya Begum, kept all these items as keepsakes in their house in Kushtia. Abrar died an agonising death after being beaten up brutally by some Chhatra League men at Buet&#39;s Sher-e-Bangla hall in the early hours of October 7 last year.</p>\r\n\r\n<p>Rokeya looks at these memories and speaks to herself in delirium.</p>', '2020-10-07', 1, ''),
(8, 'TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত', 'tbn-analysis--ep-822', '1602064023.jpg', '<p><a href=\"http://www.youtube.com/watch?v=K1SwqwHfViQ\" target=\"_blank\">TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত</a></p>', '2020-10-07', 1, ''),
(10, 'HSC, equivalent examinations cancelled, evaluation to be based on JSC, SSC results', 'hsc-equivalent-examinations-cancelled-evaluation-to-be-based-on-jsc-ssc-results', '1602061393.jpg', '<p>how are your</p>', '2020-10-07', 1, ''),
(11, 'Keepsakes are all she has', 'keepsakes-are-all-she-has', '1602061557.jpg', '<p>The books he used to read, the prizes he won, and the clothes he wore -- all are now stowed gracefully in a showcase, just the way Abrar Fahad used to keep them in his dormitory in Buet.</p>\r\n\r\n<p>A pair of blue sneakers that still looks new sits on the middle row. Just a row above lies his other belongings, starting from his wristwatch, spectacles, pen, prayer cap, tasbih, calculator, nail clipper to body lotion, toothbrush and hair oil.</p>\r\n\r\n<p>Identity cards of the university and his college rest in another row along with a yellow envelope which reads &quot;Welcome to EEE Family, Buet&quot;.</p>\r\n\r\n<p>His mother, Rokeya Begum, kept all these items as keepsakes in their house in Kushtia. Abrar died an agonising death after being beaten up brutally by some Chhatra League men at Buet&#39;s Sher-e-Bangla hall in the early hours of October 7 last year.</p>\r\n\r\n<p>Rokeya looks at these memories and speaks to herself in delirium.</p>', '2020-10-07', 1, ''),
(12, 'TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত', 'tbn-analysis--ep-822', '1602064023.jpg', '<p><a href=\"http://www.youtube.com/watch?v=K1SwqwHfViQ\" target=\"_blank\">TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত</a></p>', '2020-10-07', 1, ''),
(13, 'HSC, equivalent examinations cancelled, evaluation to be based on JSC, SSC results', 'hsc-equivalent-examinations-cancelled-evaluation-to-be-based-on-jsc-ssc-results', '1602061393.jpg', '<p>how are your</p>', '2020-10-07', 1, ''),
(14, 'Keepsakes are all she has', 'keepsakes-are-all-she-has', '1602061557.jpg', '<p>The books he used to read, the prizes he won, and the clothes he wore -- all are now stowed gracefully in a showcase, just the way Abrar Fahad used to keep them in his dormitory in Buet.</p>\r\n\r\n<p>A pair of blue sneakers that still looks new sits on the middle row. Just a row above lies his other belongings, starting from his wristwatch, spectacles, pen, prayer cap, tasbih, calculator, nail clipper to body lotion, toothbrush and hair oil.</p>\r\n\r\n<p>Identity cards of the university and his college rest in another row along with a yellow envelope which reads &quot;Welcome to EEE Family, Buet&quot;.</p>\r\n\r\n<p>His mother, Rokeya Begum, kept all these items as keepsakes in their house in Kushtia. Abrar died an agonising death after being beaten up brutally by some Chhatra League men at Buet&#39;s Sher-e-Bangla hall in the early hours of October 7 last year.</p>\r\n\r\n<p>Rokeya looks at these memories and speaks to herself in delirium.</p>', '2020-10-07', 1, ''),
(15, 'TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত', 'tbn-analysis--ep-822', '1602064023.jpg', '<p><a href=\"http://www.youtube.com/watch?v=K1SwqwHfViQ\" target=\"_blank\">TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত</a></p>', '2020-10-07', 1, ''),
(17, 'HSC, equivalent examinations cancelled, evaluation to be based on JSC, SSC results', 'hsc-equivalent-examinations-cancelled-evaluation-to-be-based-on-jsc-ssc-results', '1602061393.jpg', '<p>how are your</p>', '2020-10-07', 1, ''),
(18, 'Keepsakes are all she has', 'keepsakes-are-all-she-has', '1602061557.jpg', '<p>The books he used to read, the prizes he won, and the clothes he wore -- all are now stowed gracefully in a showcase, just the way Abrar Fahad used to keep them in his dormitory in Buet.</p>\r\n\r\n<p>A pair of blue sneakers that still looks new sits on the middle row. Just a row above lies his other belongings, starting from his wristwatch, spectacles, pen, prayer cap, tasbih, calculator, nail clipper to body lotion, toothbrush and hair oil.</p>\r\n\r\n<p>Identity cards of the university and his college rest in another row along with a yellow envelope which reads &quot;Welcome to EEE Family, Buet&quot;.</p>\r\n\r\n<p>His mother, Rokeya Begum, kept all these items as keepsakes in their house in Kushtia. Abrar died an agonising death after being beaten up brutally by some Chhatra League men at Buet&#39;s Sher-e-Bangla hall in the early hours of October 7 last year.</p>\r\n\r\n<p>Rokeya looks at these memories and speaks to herself in delirium.</p>', '2020-10-07', 1, ''),
(19, 'TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত', 'tbn-analysis--ep-822', '1602064023.jpg', '<p><a href=\"http://www.youtube.com/watch?v=K1SwqwHfViQ\" target=\"_blank\">TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত</a></p>', '2020-10-07', 1, ''),
(20, 'HSC, equivalent examinations cancelled, evaluation to be based on JSC, SSC results', 'hsc-equivalent-examinations-cancelled-evaluation-to-be-based-on-jsc-ssc-results', '1602061393.jpg', '<p>how are your</p>', '2020-10-07', 1, ''),
(21, 'Keepsakes are all she has', 'keepsakes-are-all-she-has', '1602061557.jpg', '<p>The books he used to read, the prizes he won, and the clothes he wore -- all are now stowed gracefully in a showcase, just the way Abrar Fahad used to keep them in his dormitory in Buet.</p>\r\n\r\n<p>A pair of blue sneakers that still looks new sits on the middle row. Just a row above lies his other belongings, starting from his wristwatch, spectacles, pen, prayer cap, tasbih, calculator, nail clipper to body lotion, toothbrush and hair oil.</p>\r\n\r\n<p>Identity cards of the university and his college rest in another row along with a yellow envelope which reads &quot;Welcome to EEE Family, Buet&quot;.</p>\r\n\r\n<p>His mother, Rokeya Begum, kept all these items as keepsakes in their house in Kushtia. Abrar died an agonising death after being beaten up brutally by some Chhatra League men at Buet&#39;s Sher-e-Bangla hall in the early hours of October 7 last year.</p>\r\n\r\n<p>Rokeya looks at these memories and speaks to herself in delirium.</p>', '2020-10-07', 1, ''),
(22, 'TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত', 'tbn-analysis--ep-822', '1602064023.jpg', '<p><a href=\"http://www.youtube.com/watch?v=K1SwqwHfViQ\" target=\"_blank\">TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত</a></p>', '2020-10-07', 1, ''),
(24, 'HSC, equivalent examinations cancelled, evaluation to be based on JSC, SSC results', 'hsc-equivalent-examinations-cancelled-evaluation-to-be-based-on-jsc-ssc-results', '1602061393.jpg', '<p>how are your</p>', '2020-10-07', 1, ''),
(25, 'Keepsakes are all she has', 'keepsakes-are-all-she-has', '1602061557.jpg', '<p>The books he used to read, the prizes he won, and the clothes he wore -- all are now stowed gracefully in a showcase, just the way Abrar Fahad used to keep them in his dormitory in Buet.</p>\r\n\r\n<p>A pair of blue sneakers that still looks new sits on the middle row. Just a row above lies his other belongings, starting from his wristwatch, spectacles, pen, prayer cap, tasbih, calculator, nail clipper to body lotion, toothbrush and hair oil.</p>\r\n\r\n<p>Identity cards of the university and his college rest in another row along with a yellow envelope which reads &quot;Welcome to EEE Family, Buet&quot;.</p>\r\n\r\n<p>His mother, Rokeya Begum, kept all these items as keepsakes in their house in Kushtia. Abrar died an agonising death after being beaten up brutally by some Chhatra League men at Buet&#39;s Sher-e-Bangla hall in the early hours of October 7 last year.</p>\r\n\r\n<p>Rokeya looks at these memories and speaks to herself in delirium.</p>', '2020-10-07', 1, ''),
(26, 'TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত', 'tbn-analysis--ep-822', '1602064023.jpg', '<p><a href=\"http://www.youtube.com/watch?v=K1SwqwHfViQ\" target=\"_blank\">TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত</a></p>', '2020-10-07', 1, ''),
(27, 'HSC, equivalent examinations cancelled, evaluation to be based on JSC, SSC results', 'hsc-equivalent-examinations-cancelled-evaluation-to-be-based-on-jsc-ssc-results', '1602061393.jpg', '<p>how are your</p>', '2020-10-07', 1, ''),
(28, 'Keepsakes are all she has', 'keepsakes-are-all-she-has', '1602061557.jpg', '<p>The books he used to read, the prizes he won, and the clothes he wore -- all are now stowed gracefully in a showcase, just the way Abrar Fahad used to keep them in his dormitory in Buet.</p>\r\n\r\n<p>A pair of blue sneakers that still looks new sits on the middle row. Just a row above lies his other belongings, starting from his wristwatch, spectacles, pen, prayer cap, tasbih, calculator, nail clipper to body lotion, toothbrush and hair oil.</p>\r\n\r\n<p>Identity cards of the university and his college rest in another row along with a yellow envelope which reads &quot;Welcome to EEE Family, Buet&quot;.</p>\r\n\r\n<p>His mother, Rokeya Begum, kept all these items as keepsakes in their house in Kushtia. Abrar died an agonising death after being beaten up brutally by some Chhatra League men at Buet&#39;s Sher-e-Bangla hall in the early hours of October 7 last year.</p>\r\n\r\n<p>Rokeya looks at these memories and speaks to herself in delirium.</p>', '2020-10-07', 1, ''),
(29, 'eee', 'tbn-analysis--ep-822', '1602064023.jpg', '<p><a href=\"http://www.youtube.com/watch?v=K1SwqwHfViQ\" target=\"_blank\">TBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্তTBN Analysis | EP 822 | বেকারত্ব ভাতা বাস্ত</a></p>', '2020-10-07', 1, ''),
(31, 'Man wather price of wold', 'man-wather-price-of-wold-', '1602075527.jpg', '<p>dddddddd</p>', '2020-10-07', 1, 'isolutions');

-- --------------------------------------------------------

--
-- Table structure for table `post_category_relation`
--

CREATE TABLE `post_category_relation` (
  `post_category_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post_category_relation`
--

INSERT INTO `post_category_relation` (`post_category_id`, `category_id`, `post_id`) VALUES
(1, 3, 4),
(2, 4, 5),
(3, 3, 5),
(4, 2, 5),
(11, 4, 29),
(12, 3, 29),
(13, 2, 29),
(14, 4, 24),
(15, 3, 24),
(16, 2, 24),
(17, 4, 22),
(18, 3, 22),
(19, 2, 22),
(20, 4, 25),
(21, 3, 25),
(22, 2, 25),
(23, 4, 31),
(24, 3, 31),
(25, 2, 31);

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `program_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `program_details` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `program_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`id`, `program_name`, `program_details`, `youtube`, `status`, `program_image`, `created_at`, `updated_at`) VALUES
(3, 'TBN24 AM NEWS', 'TBN24 AM NEWS', 'TBN24 AM NEWS', 1, '1600861547.jpg', '2020-09-21 18:00:00', NULL),
(4, 'TBN WELLNESS', 'TBN WELLNESS', '545228771152222', 1, '1600861504.jpg', '2020-09-21 18:00:00', NULL),
(5, 'News Flash', 'News Flash', 'fffd', 1, '1600861471.jpg', '2020-09-21 18:00:00', NULL),
(6, 'কুরআনের আলো', 'detail ki', '4455', 1, '1600861349.jpg', '2020-09-22 18:00:00', NULL),
(7, 'aso islam siki', 'ddd', 'fff', 1, '1600862030.jpg', '2020-09-22 18:00:00', NULL),
(8, 'ajker kobor', 'dd', 'dff', 1, '1600862052.jpg', '2020-09-22 18:00:00', NULL),
(9, 'Alif laila', 'how are you', 'ddd', 1, '1602047676.webp', '2020-10-06 18:00:00', NULL),
(11, 'Alif laila', 'Somethidng', 'gfgjgjjg', 1, '1602222371.webp', '2020-10-08 18:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pulls`
--

CREATE TABLE `pulls` (
  `pull_id` int(11) NOT NULL,
  `pull_question` varchar(200) DEFAULT NULL,
  `pull_expire_time` date DEFAULT NULL,
  `pull_status` tinyint(1) DEFAULT NULL,
  `pull_created_date` date NOT NULL DEFAULT current_timestamp(),
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pulls`
--

INSERT INTO `pulls` (`pull_id`, `pull_question`, `pull_expire_time`, `pull_status`, `pull_created_date`, `created_at`) VALUES
(10, 'Who is the Best', '2020-10-13', 1, '2020-10-04', '2020-10-04'),
(17, 'what is yout name', '2020-10-08', 0, '2020-10-05', '2020-10-05'),
(18, 'fff', '2020-10-09', NULL, '2020-10-09', '2020-10-09');

-- --------------------------------------------------------

--
-- Table structure for table `pull_add_option`
--

CREATE TABLE `pull_add_option` (
  `pull_add_option_id` int(11) NOT NULL,
  `pull_id` int(11) NOT NULL,
  `option_name` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pull_add_option`
--

INSERT INTO `pull_add_option` (`pull_add_option_id`, `pull_id`, `option_name`, `created_date`) VALUES
(22, 10, 'A', '2020-10-04 16:00:27'),
(23, 10, 'B', '2020-10-04 16:00:27'),
(24, 10, 'C', '2020-10-04 16:00:27'),
(25, 11, 'mitul', '2020-10-04 16:33:31'),
(26, 11, 'Milon', '2020-10-04 16:33:31'),
(27, 11, 'Abdullah', '2020-10-04 16:33:32'),
(28, 11, 'Kutub', '2020-10-04 16:33:32'),
(31, 17, 'mitul hhh', '2020-10-05 13:16:19'),
(32, 17, 'mitulfgr', '2020-10-05 13:16:19'),
(33, 17, 'mituld g', '2020-10-05 13:16:19'),
(34, 17, 'mitul gg', '2020-10-05 13:16:19');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `program_id` int(11) NOT NULL,
  `schedule_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `chat_status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `schedule_note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `program_id`, `schedule_date`, `start_time`, `end_time`, `chat_status`, `created_at`, `updated_at`, `schedule_note`, `day`) VALUES
(1, 4, '2020-09-16', '00:00:00', '00:00:00', 1, '2020-09-25 18:00:00', NULL, NULL, 'Sat'),
(2, 4, '2020-09-16', '00:30:00', '00:30:00', 1, '2020-09-23 18:00:00', NULL, '555', NULL),
(8, 7, '2020-09-26', '00:45:00', '00:30:00', 1, '2020-09-25 18:00:00', NULL, '888', 'Sat'),
(9, 8, '2020-09-26', '00:45:00', '01:00:00', 0, '2020-09-25 18:00:00', NULL, '888', NULL),
(10, 3, '2020-09-23', '01:00:00', '00:45:00', 0, '2020-09-25 18:00:00', NULL, NULL, 'Sat'),
(11, 7, '2020-09-26', '00:30:00', '00:30:00', NULL, '2020-09-25 18:00:00', NULL, NULL, NULL),
(12, 6, '2020-09-24', '00:00:00', '00:00:00', 0, '2020-09-25 18:00:00', NULL, '888', NULL),
(13, 5, '2020-09-26', '01:00:00', '01:00:00', 0, '2020-09-25 18:00:00', NULL, 'hhh 45', 'Sat'),
(14, 5, '2020-09-10', '00:45:00', '00:00:00', 0, '2020-09-25 18:00:00', NULL, 'hhh 45', 'Sat'),
(15, 5, '2020-09-08', '00:30:00', '00:45:00', 1, '2020-09-25 18:00:00', NULL, '888', 'Sat'),
(16, 4, '2020-09-09', '00:30:00', '00:30:00', 0, '2020-09-25 18:00:00', NULL, 'hhh 45', 'Saturday'),
(17, 6, '2020-09-16', '00:15:00', '00:45:00', 1, '2020-09-26 18:00:00', NULL, 'dd', 'Sunday'),
(18, 6, '2020-09-27', '00:45:00', '00:45:00', 1, '2020-09-26 18:00:00', NULL, '888', 'Sunday'),
(19, 7, '2020-09-27', '01:00:00', '01:45:00', 0, '2020-10-08 18:00:00', NULL, 'hhh 45', 'Friday'),
(20, 5, '2020-09-29', '00:30:00', '01:00:00', 1, '2020-09-28 18:00:00', NULL, '888', 'Tuesday'),
(21, 7, '2020-09-18', '01:00:00', '01:00:00', NULL, '2020-10-06 18:00:00', NULL, 'hhh 45', 'Wednesday'),
(22, 6, '2020-10-13', '00:30:00', '00:15:00', 1, '2020-10-06 18:00:00', NULL, NULL, 'Wednesday'),
(23, 3, '2020-10-08', '00:45:00', '00:30:00', 1, '2020-10-07 18:00:00', NULL, 'uyhgg', 'Thursday'),
(24, 6, '2020-10-08', '13:30:00', '16:45:00', 1, '2020-10-08 18:00:00', NULL, 'jhhh', 'Friday'),
(25, 3, '2020-10-13', '12:33:00', '12:45:00', 0, '2020-10-08 18:00:00', NULL, NULL, 'Friday'),
(26, 3, '2020-10-22', '12:55:00', '12:13:00', NULL, '2020-10-08 18:00:00', NULL, NULL, 'Friday'),
(27, 6, '2020-10-12', '09:45:00', '10:52:00', 1, '2020-10-08 18:00:00', NULL, NULL, 'Friday');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `country` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `continent_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `country`, `city`, `ip`, `continent_name`, `region`, `address`, `picture`) VALUES
(1, 'Shahinul islam', 'a@gmail.com', '', NULL, 'c4ca4238a0b923820dcc509a6f75849b', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'customer16891601471063.jpg'),
(2, 'abdullah', 'abdullah@gmail.com', '01738305670', NULL, 'e10adc3949ba59abbe56e057f20f883e', '16013682004089', '2020-09-29 14:30:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, ''),
(3, 'sujon', 'admin@isolutionsbd.com', 'dddd', NULL, '343d9040a671c45832ee5381860e2996', '16013683733672', '2020-09-29 14:32:53', NULL, NULL, NULL, NULL, NULL, NULL, NULL, ''),
(5, 'admin', 'adffmin@isolutionsbd.com', '01571133188', NULL, 'e10adc3949ba59abbe56e057f20f883e', '16013697331930', '2020-09-29 14:55:33', NULL, 'Bangladesh', NULL, '103.92.214.8', NULL, NULL, NULL, ''),
(6, 'sujon', 'info@isolutionsbd.com', '01735887144d', NULL, '8277e0910d750195b448797616e091ad', '16013698873526', '2020-09-29 14:58:07', NULL, 'Bangladesh', 'Dhaka', '103.92.214.8', 'Asia', NULL, NULL, ''),
(7, 'mitul f', 'suzonicde1@gmal.com', '01738d30567', NULL, '77963b7a931377ad4ab5ad6a9cd718aa', '16013729763971', '2020-09-29 15:49:37', NULL, 'Bangladesh', 'Dhakadd', '103.92.214.8', 'Asia', 'Dhaka Division', 'address', ''),
(8, 'ddd', 'suzonice10@gmal.com', '017387830567', NULL, 'c4ca4238a0b923820dcc509a6f75849b', '16013746732330', '2020-09-29 16:17:53', NULL, 'Bangladesh', 'Dhaka', '103.92.214.8', 'Asia', 'Dhaka Division', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `vote`
--

CREATE TABLE `vote` (
  `vote_id` int(11) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `pull_id` int(200) NOT NULL,
  `option_id` int(200) NOT NULL,
  `ip` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote`
--

INSERT INTO `vote` (`vote_id`, `create_date`, `pull_id`, `option_id`, `ip`) VALUES
(59, '2020-10-05 19:17:44', 10, 23, '::1'),
(60, '2020-10-05 19:17:44', 10, 23, '::1'),
(61, '2020-10-05 19:18:09', 17, 32, '::1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `app_seating`
--
ALTER TABLE `app_seating`
  ADD PRIMARY KEY (`app_setting_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`faq_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`option_id`);

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `playlists`
--
ALTER TABLE `playlists`
  ADD PRIMARY KEY (`playlist_id`);

--
-- Indexes for table `popular_video`
--
ALTER TABLE `popular_video`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `post_category_relation`
--
ALTER TABLE `post_category_relation`
  ADD PRIMARY KEY (`post_category_id`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pulls`
--
ALTER TABLE `pulls`
  ADD PRIMARY KEY (`pull_id`);

--
-- Indexes for table `pull_add_option`
--
ALTER TABLE `pull_add_option`
  ADD PRIMARY KEY (`pull_add_option_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `vote`
--
ALTER TABLE `vote`
  ADD PRIMARY KEY (`vote_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `app_seating`
--
ALTER TABLE `app_seating`
  MODIFY `app_setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `faq_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `page`
--
ALTER TABLE `page`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `playlists`
--
ALTER TABLE `playlists`
  MODIFY `playlist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `popular_video`
--
ALTER TABLE `popular_video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `post_category_relation`
--
ALTER TABLE `post_category_relation`
  MODIFY `post_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `programs`
--
ALTER TABLE `programs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pulls`
--
ALTER TABLE `pulls`
  MODIFY `pull_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `pull_add_option`
--
ALTER TABLE `pull_add_option`
  MODIFY `pull_add_option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `vote`
--
ALTER TABLE `vote`
  MODIFY `vote_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
